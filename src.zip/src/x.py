import requests
import bs4
import re
from bs4 import BeautifulSoup
url="https://www.baidu.com/s?rtt=1&bsst=1&cl=2&tn=news&rsv_dl=ns_pc&word=%E5%8D%9A%E7%89%A9%E9%A6%86"
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36'
}
re=requests.get(url,headers=headers)
soup=soup=BeautifulSoup(re.text,"html.parser")
print(soup)